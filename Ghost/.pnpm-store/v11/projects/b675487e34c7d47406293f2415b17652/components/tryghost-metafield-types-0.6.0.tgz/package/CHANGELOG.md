# @tryghost/metafield-types

## 0.6.0

### Minor Changes

- Added a way to build a new field type behind a Labs flag. `FIELD_TYPE_FLAGS` lists the types still in development with the Labs flag each is behind, and a type with no flag there is released. `isCreatableType(type, isFlagOn)` says whether a field of a type can be created given which flags are on. Every type is released today.

- Added `hasOnlyPhoneCharacters(text)` to the `./phone` entry point. It returns whether text contains only characters valid in a phone number (digits, +, spaces and the punctuation libphonenumber-js accepts), so a phone input can flag an invalid character while typing without loading the library. A number it flags is one the phone field's validation rejects too, except an RFC 3966 `tel:` URI, which the library accepts.

- Added `phoneCountryOfTimeZone`, the country of a time zone such as Portugal for `Europe/Lisbon`, from the browser's own time zone data. `startPhoneEntry` takes an optional time zone and, for a field holding no number, starts from its country before the country of the reader's language, as many browsers speak `en-US` wherever they are. Safari names some zones newer than its own data does, such as `Asia/Kolkata`, and its readers there are given their language's country, as before.

- Added the `phone` field type, a text leaf in the new `phone` format, developed behind the `customFieldTypePhone` Labs flag. Its rule keeps a number in E.164 (`+442079460000`) however it was written, after a + or the 00 most countries dial abroad with. It accepts only a number its country has given out, as libphonenumber-js's full metadata has them, and refuses one without its country code, one with anything else around it, and one with an extension.

  `phoneNumberIn(text, country)` reads a phone number the same way, as it is dialled in a country unless it was written with a country code of its own, and gives it in E.164, or undefined when it isn't a number a phone field could keep.

  `filterTextFor(leaf, typed, country)` is what a filter on a text leaf looks for: what was typed, as the leaf's field holds it. A phone field's filter then finds a number held in E.164 however it was written: a whole number in E.164, read in `country` unless it gives its code, and part of one as its digits.

  The `./phone` entry point, which a browser app can load without zod or libphonenumber-js, holds what a phone input beside a choice of country needs: what it starts from, shows and sends as someone types or picks a country (`startPhoneEntry`, `typeNumber`, `pickCountry`, `shownCountry`, `withCallingCode`), each country's calling code and way of dialling abroad (`CALLING_CODES`, `INTERNATIONAL_PREFIXES`), what tells apart the countries sharing a calling code (`SHARED_CODES`), `phoneCountryOptions`, `readCallingCode`, `phoneCountryOfLocales`, `isPhoneCountry` and `flagOf`.

- Removed `flagOf` from the `./phone` entry point. It drew a country's flag as an emoji, which Windows shows as two letters, and nothing uses it now that Portal's phone input shows the calling code alone.

- Renamed a text leaf's `size` to `format`, `TEXT_SIZES` to `TEXT_FORMATS` and `TextSize` to `TextFormat`. What sets a text leaf apart isn't always how much text it holds: a format can also be text in a particular shape, such as a phone number.

### Patch Changes

- In Node, libphonenumber-js now loads the first time a phone number is read rather than when the package is imported, so a server that never reads one doesn't hold its metadata. Bundles still load it up front.

- Changed the README to point contributors at the package's new docs folder.

- Changed the package's repository directory to `contracts/metafield-types`, where its source now lives in the Ghost repository.

- Changed `phoneCountryOptions` to put each calling code in parentheses, such as `United Kingdom (+44)`.

- Changed phone number validation errors to be specific to the number's country. An invalid number now gets an example from its own country, such as `+55 11 96123 4567` for a +55 number, where every error used to show a British one. The error also says when the number is too short or too long, or when its country code doesn't exist.

## 0.5.0

### Minor Changes

- Added a way to build a new field type behind a Labs flag. `FIELD_TYPE_FLAGS` lists the types still in development with the Labs flag each is behind, and a type with no flag there is released. `isCreatableType(type, isFlagOn)` says whether a field of a type can be created given which flags are on. Every type is released today.

- Added the `phone` field type, a text leaf in the new `phone` format, developed behind the `customFieldTypePhone` Labs flag. Its rule keeps a number in E.164 (`+442079460000`) however it was written, after a + or the 00 most countries dial abroad with. It accepts only a number its country has given out, as libphonenumber-js's full metadata has them, and refuses one without its country code, one with anything else around it, and one with an extension.

  `phoneNumberIn(text, country)` reads a phone number the same way, as it is dialled in a country unless it was written with a country code of its own, and gives it in E.164, or undefined when it isn't a number a phone field could keep.

  `filterTextFor(leaf, typed, country)` is what a filter on a text leaf looks for: what was typed, as the leaf's field holds it. A phone field's filter then finds a number held in E.164 however it was written: a whole number in E.164, read in `country` unless it gives its code, and part of one as its digits.

  The `./phone` entry point, which a browser app can load without zod or libphonenumber-js, holds what a phone input beside a choice of country needs: what it starts from, shows and sends as someone types or picks a country (`startPhoneEntry`, `typeNumber`, `pickCountry`, `shownCountry`, `withCallingCode`), each country's calling code and way of dialling abroad (`CALLING_CODES`, `INTERNATIONAL_PREFIXES`), what tells apart the countries sharing a calling code (`SHARED_CODES`), `phoneCountryOptions`, `readCallingCode`, `phoneCountryOfLocales`, `isPhoneCountry` and `flagOf`.

- Renamed a text leaf's `size` to `format`, `TEXT_SIZES` to `TEXT_FORMATS` and `TextSize` to `TextFormat`. What sets a text leaf apart isn't always how much text it holds: a format can also be text in a particular shape, such as a phone number.

### Patch Changes

- Changed the README to point contributors at the package's new docs folder.

## 0.4.0

### Minor Changes

- Changed how a write clears a value, and described each field shape's rules once, in the package.

  - `null` is the only way a write clears. A write of `''` to a text field, `[]` to a list, or `''` to a part of an address is refused by `valueSchemaFor` with a message saying to send `null`. A part of an address named as `null` is cleared; before, `null` for a part was refused.
  - A value never holds nothing: a field holding nothing has no value, rather than an empty one. `ValueOf<T>` and `FieldValue` no longer admit `null` or `''` parts, and a write has its own type, `WriteOf<T>` and `FieldWrite`, which does.
  - `./shapes` is a new entry point, zod-free like `./structure`. `SHAPES` holds each shape's rules (`parse`, `same`, `apply`, `diff`), `LEAVES` each kind of leaf's (its JSON kind, `read`, `fromText`), and `FIELD_READING` how a field reads a held value (`held`, `editable`). `shaped(field)` and `shapedType(type)` pair a field or type with its shape, so a table keyed by shape can be indexed with it without a cast. `heldValue`, `editableValue`, `valueFromText`, `textOfValue`, `heldTextOf`, `formTextOf`, `formShows` and `formWrite` read a held value and work out the write a form makes.
  - `accept(shaped(field), raw)` checks a write against the field's strict rule and returns an `Accepted` value branded with its shape, so code that stores a value can require one that passed the rule.
  - `keysOf(value)` lists an object's keys typed as its type's keys. `LeafValues`, `LeafValue`, `LeafKind` and `WriteOf` are exported from `./structure`.

- Changed a repeated list option to be refused on the option that repeats an earlier one, and options to repeat each other whatever their case.

  - `SetSettingsSchema` refuses a repeat at `options.<index>` of the later option, with "This option already exists.". It used to refuse the list at `options` with "Give each option once.".
  - Two options are the same option when their text matches without regard to case, so a list can't offer both "Podcasts" and "podcasts". It used to compare text exactly.
  - `optionKey(option)` is exported from `./structure`: the text two options are compared by, so a client that tidies a list skips the same repeats the schema refuses.

## 0.3.0

### Minor Changes

- Changed the catalog to describe each field type as a composition of building blocks, and to derive each type's rule from them.

  - `FIELD_STRUCTURES` replaces `FIELD_PARTS`. A type is one leaf, `{ shape: 'scalar', leaf }`, or a record of named leaves, `{ shape: 'record', parts }`.
  - A leaf is text of a size, `text(size)` with `TEXT_SIZES`, or a choice from a list, `choice(from)` with `LIST_SOURCES`. `country` is the choice from the list of countries.
  - A part's type is now its leaf, so `PART_TYPE_IDS`, `PartType` and `partTypesOf` are removed. An address's postal code is `text('code')`, its country is `country`, and its other parts are `text('line')`.
  - `FIELD_KINDS` and `FieldKind` are removed. A scalar's leaf says what it holds.
  - `matchShape(type, { scalar, record })` and `matchLeaf(leaf, { text, choice })` call the handler for a type's shape or a leaf's kind, so a caller has to say what it does with every one. `matchShape` throws for a type the package doesn't know, so check a type from the wire with `isFieldType` first.
  - `isRecordValue` tells whether a value is laid out as a record of parts.
  - `StructureOf`, `ShapeOf`, `FieldTypeOfShape` and `PartsOf` name what a type is composed of, and `ValueOf` names the value it holds.
  - `partsOf` names a record's parts as plain strings. Read one type's parts by name from `FIELD_STRUCTURES[type].parts`, whose keys are typed.
  - `valueSchemaFor(field)` is the rule a value of one field must satisfy, derived from its type's composition. It replaces `FIELD_TYPES`, `FieldTypeDefinition`, `PART_TYPES` and `AddressValue`, which are removed. `FieldValue` and `Address` stay.

- Added helpers for editing a list field's answers.

  - `inOptionOrder(settings, held)` is the answers among `held` that a list offers, in its order, and `editableAnswers(settings, held)` is what a form editing a list's answers starts from: none while a field taking one holds several.

- Added the list field type, whose field offers options of its own and takes one or several of them.

  - `list` is `{ shape: 'set' }`: a value is the text of each option picked, as `string[]`, even when the field takes one. `matchShape` handlers take a `set` branch.
  - A field now carries `settings` beside its `type`. `SettingsOf<T>` is what a type is set up with: `SetSettings` (`options`, in the order shown, and `multiple`) for a list, and nothing for every other type, so a field of another type has no settings. `TypedSettings` pairs a type with its settings. `withTypedSettings(base, settings)` builds what a field holds beside its type with that pair, a variant per shape, from how each shape's settings are held: `WRITTEN_SETTINGS` checks them against the rules, and `READ_SETTINGS` reads them back by `SetSettingsShape` alone, so a rule tightened later never hides a field set up under the old one. `TypedSettingsInputSchema` and `TypedSettingsSchema` are the pair on its own, and `MetafieldDefinitionSchema` is built the same way. `typesOfShape(shape)` lists the types of a shape.
  - `MetafieldDefinitionSchema` reads `settings`, and `MetafieldDefinition` is typed by them, so a list definition always has its options.
  - `valueSchemaFor(field)` takes the field's type and settings. A list's rule accepts only the options its field offers, and at most one when it takes one.
  - `matchField(field, handlers)` calls a handler for the field's shape with the field narrowed, settings included.
  - `optionText` is how an option's text is matched: trimmed, with accents encoded one way. `MIN_OPTIONS`, `MAX_OPTIONS` and `OPTION_SEPARATOR` are a list's limits and the character joining options in one CSV cell, which no option may contain.

- Added `SHAPE_SETTINGS`, each field shape's settings in one place: the shape a read is checked against, the rules a write is checked against on top of that shape, and the defaults a field starts with. `WRITTEN_SETTINGS` and `READ_SETTINGS` are now taken from it, and `SetSettingsSchema` is now built on `SetSettingsShape`.

- Added `refusedProperty(path)`, which names where a refusal points within what was sent by its path, with parts and positions joined by dots, such as `settings.options.2` for a field's third option. Ghost reports a custom field refusal's `property` this way, and a form can file the problems it finds under the same keys.

- Added the shape of a field definition as the Admin and Members APIs return it.

  - `MetafieldDefinitionSchema` reads a definition (namespace, key, name, type, status, member access and dates) and `MetafieldDefinition` is the type it produces. Ghost writes every definition through it.
  - `FIELD_STATUSES`, `FieldStatusSchema`, `FIELD_STATUS` and `FieldStatus` name whether a field is active or archived.

### Patch Changes

- Pointed the README at a guide for Ghost contributors adding a field type.

- Updated dependencies

- Updated dependencies

- Updated dependencies

## 0.2.0

### Minor Changes

- Changed `./identity` to name a field through types that only a check produces, and renamed the parts helper.

  - `IdentityTextSchema` reads an identity such as `custom.shipping_address.country` into its namespace, key and parts, and writes one back. `z.safeDecode(IdentityTextSchema, text)` replaces `parseIdentity`, and `z.encode(IdentityTextSchema, identity)` replaces `formatIdentity`.
  - `IdentitySchema` checks an identity whose segments arrive apart, such as a route's namespace and key. Reading a whole field's identity can leave `parts` out; what it reads always has them.
  - `NamespaceSchema`, `KeySchema` and `PartSchema` check one segment each and produce the `Namespace`, `Key` and `Part` types. They replace `IDENTITY_SEGMENT`.
  - `Identity` is the decoded shape, with `parts` in place of `partPath`. `FieldIdentity` and `FieldIdentityString` are removed.
  - `CUSTOM_NAMESPACE` is a `Namespace` rather than the literal `'custom'`.
  - `./identity` now loads `zod/mini`.
  - `subFieldsOf` is renamed `partsOf`.

### Patch Changes

- Corrected the description of CUSTOM_NAMESPACE: every field now records its namespace, so the constant only matters to code that speaks for the publisher's own fields.

## 0.1.2

### Patch Changes

- Updated dependencies

## 0.1.1

### Patch Changes

- Updated zod dependency
