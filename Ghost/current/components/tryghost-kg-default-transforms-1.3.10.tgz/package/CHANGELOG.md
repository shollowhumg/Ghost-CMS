# @tryghost/kg-default-transforms

## 1.3.10

### Patch Changes

- Updated dependencies

## 1.3.9

### Patch Changes

- Updated dependencies

- Updated dependencies:
  - @tryghost/kg-default-nodes@2.3.0

## 1.3.8

### Patch Changes

- Stopped publishing the TypeScript incremental build cache (build/tsconfig.tsbuildinfo) in the npm package

## 1.3.7

### Patch Changes

- Updated dependencies

## 1.3.6

### Patch Changes

- Republished with npm trusted publishing and provenance; no code changes
