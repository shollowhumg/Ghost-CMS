# @tryghost/kg-utils

## 1.1.10

### Patch Changes

- Updated dependencies

## 1.1.9

### Patch Changes

- Updated dependencies

- Updated dependencies

## 1.1.8

### Patch Changes

- Stopped publishing the TypeScript incremental build cache (build/tsconfig.tsbuildinfo) in the npm package

## 1.1.7

### Patch Changes

- Updated dependencies

## 1.1.6

### Patch Changes

- Republished with npm trusted publishing and provenance; no code changes
